# World Economy Freedom

The original data from Kaggle is in the `.xlsx` file.

I converted that spreadsheet to CSV and added it here.
